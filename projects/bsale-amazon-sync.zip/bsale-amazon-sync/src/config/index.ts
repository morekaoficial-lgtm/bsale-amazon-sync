import 'dotenv/config';

export const config = {
  server: {
    port: parseInt(process.env.PORT || '3000', 10),
    nodeEnv: process.env.NODE_ENV || 'development',
  },
  
  bsale: {
    token: process.env.BSALE_API_TOKEN || '',
    baseUrl: process.env.BSALE_BASE_URL || 'https://api.bsale.io/v1',
    officeId: parseInt(process.env.BSALE_OFFICE_ID || '1', 10),
  },
  
  amazon: {
    lwaClientId: process.env.AMAZON_LWA_CLIENT_ID || '',
    lwaClientSecret: process.env.AMAZON_LWA_CLIENT_SECRET || '',
    refreshToken: process.env.AMAZON_REFRESH_TOKEN || '',
    awsAccessKey: process.env.AMAZON_AWS_ACCESS_KEY || '',
    awsSecretKey: process.env.AMAZON_AWS_SECRET_KEY || '',
    awsRegion: process.env.AMAZON_AWS_REGION || 'us-east-1',
    marketplaceId: process.env.AMAZON_MARKETPLACE_ID || 'A1AM78C64UM0Y8',
    roleArn: process.env.AMAZON_ROLE_ARN,
  },
  
  sync: {
    intervalMinutes: parseInt(process.env.SYNC_INTERVAL_MINUTES || '30', 10),
    stockThreshold: parseInt(process.env.STOCK_THRESHOLD || '0', 10),
  },
};
