import 'dotenv/config';
import express, { Request, Response, NextFunction } from 'express';
import webhookRoutes from './routes/webhooks';
import { SyncService } from './services/syncService';
import { config } from './config';

const app = express();
const syncService = new SyncService();

// Middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Request logging
app.use((req: Request, _res: Response, next: NextFunction) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`);
  next();
});

// Routes
app.use('/webhook', webhookRoutes);

// Root endpoint
app.get('/', (_req: Request, res: Response) => {
  res.json({
    service: 'BSale ↔ Amazon Sync',
    version: '1.0.0',
    status: 'running',
    endpoints: {
      health: 'GET /webhook/health',
      bsaleWebhook: 'POST /webhook/bsale',
      syncAll: 'POST /webhook/sync/all',
      syncSku: 'POST /webhook/sync/sku/:sku',
      logs: 'GET /webhook/logs',
      status: 'GET /webhook/status',
    },
  });
});

// Error handler
app.use((err: Error, _req: Request, res: Response, _next: NextFunction) => {
  console.error('[Error]', err.stack);
  res.status(500).json({ error: err.message });
});

// 404 handler
app.use((_req: Request, res: Response) => {
  res.status(404).json({ error: 'Endpoint no encontrado' });
});

// Start server
const PORT = config.server.port;

app.listen(PORT, () => {
  console.log(`
╔══════════════════════════════════════════════════════════════╗
║           BSale ↔ Amazon Sync — Servidor Iniciado            ║
╠══════════════════════════════════════════════════════════════╣
║  Puerto: ${PORT.toString().padEnd(51)} ║
║  Modo:   ${config.server.nodeEnv.padEnd(51)} ║
║  BSale:  ${(config.bsale.baseUrl || 'NO CONFIGURADO').padEnd(51)} ║
║  Amazon: ${(config.amazon.marketplaceId || 'NO CONFIGURADO').padEnd(51)} ║
╚══════════════════════════════════════════════════════════════╝
  `);
  
  // Iniciar sincronización automática si está configurada
  syncService.startAutoSync();
});
