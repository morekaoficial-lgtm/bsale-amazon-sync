import axios from 'axios';
import { createHmac } from 'crypto';
import { config } from '../config';
import { AmazonInventoryItem, AmazonInventoryPayload, AmazonTokenResponse } from '../types';

/**
 * Servicio para interactuar con Amazon Selling Partner API (SP-API)
 * 
 * Documentación:
 * - https://developer-docs.amazon.com/sp-api/
 * - https://developer-docs.amazon.com/sp-api/docs/fba-inventory-api-v1-reference
 */
export class AmazonService {
  private accessToken: string | null = null;
  private tokenExpiresAt: number = 0;
  
  // Endpoints de Amazon SP-API
  private readonly spApiEndpoint = 'https://sellingpartnerapi-na.amazon.com';
  private readonly tokenEndpoint = 'https://api.amazon.com/auth/o2/token';

  /**
   * Obtener access token de Amazon (LWA - Login with Amazon)
   * Se renueva automáticamente cuando expira
   */
  async getAccessToken(): Promise<string> {
    // Si el token aún es válido, reusarlo
    if (this.accessToken && Date.now() < this.tokenExpiresAt - 60000) {
      return this.accessToken;
    }
    
    try {
      console.log('[AmazonService] Renovando access token...');
      
      const response = await axios.post<AmazonTokenResponse>(
        this.tokenEndpoint,
        new URLSearchParams({
          grant_type: 'refresh_token',
          refresh_token: config.amazon.refreshToken,
          client_id: config.amazon.lwaClientId,
          client_secret: config.amazon.lwaClientSecret,
        }),
        {
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          timeout: 30000,
        }
      );
      
      this.accessToken = response.data.access_token;
      this.tokenExpiresAt = Date.now() + (response.data.expires_in * 1000);
      
      console.log('[AmazonService] Token renovado exitosamente');
      return this.accessToken;
    } catch (error: any) {
      console.error('[AmazonService] Error obteniendo token:', error.response?.data || error.message);
      throw new Error(`No se pudo obtener token de Amazon: ${error.message}`);
    }
  }

  /**
   * Generar firma AWS para requests a SP-API (AWS Signature Version 4)
   * 
   * NOTA: En producción, es mejor usar el SDK oficial de AWS para esto.
   * Esta es una implementación simplificada.
   */
  private signRequest(
    method: string,
    uri: string,
    queryString: string,
    headers: Record<string, string>,
    payload: string
  ): Record<string, string> {
    // Para producción, usa aws4fetch o @aws-sdk/signature-v4
    // Aquí dejamos la implementación simplificada
    return headers;
  }

  /**
   * Actualizar inventario de un producto en Amazon
   * Usa el endpoint PUT /fba/inventory/v1/items
   * 
   * NOTA: Para actualizar stock de productos FBA vs FBM, los endpoints difieren.
   * Este método usa el endpoint de inventory para seller-fulfilled (FBM).
   * Para FBA, usarías el endpoint de shipments/feeds.
   */
  async updateInventory(sku: string, quantity: number): Promise<boolean> {
    try {
      const token = await this.getAccessToken();
      
      // Para FBM (Fulfillment by Merchant):
      // Usamos el endpoint de listings items para actualizar quantity
      const url = `${this.spApiEndpoint}/listings/2021-08-01/items/${config.amazon.marketplaceId}/${encodeURIComponent(sku)}`;
      
      const payload = {
        productType: 'POWERBANK',  // Ajustar según el producto
        requirements: 'LISTING_OFFER_ONLY',
        attributes: {
          quantity: [
            {
              value: quantity,
              marketplace_id: config.amazon.marketplaceId,
            }
          ]
        }
      };
      
      const response = await axios.patch(url, payload, {
        headers: {
          'x-amz-access-token': token,
          'Content-Type': 'application/json',
        },
        timeout: 30000,
      });
      
      console.log(`[AmazonService] Stock actualizado para SKU ${sku}: ${quantity} unidades`);
      return true;
    } catch (error: any) {
      console.error(`[AmazonService] Error actualizando stock para ${sku}:`, error.response?.data || error.message);
      return false;
    }
  }

  /**
   * Obtener inventario actual de un SKU en Amazon
   */
  async getInventory(sku: string): Promise<number> {
    try {
      const token = await this.getAccessToken();
      
      const url = `${this.spApiEndpoint}/fba/inventory/v1/items`;
      
      const response = await axios.get(url, {
        headers: {
          'x-amz-access-token': token,
        },
        params: {
          marketplaceIds: config.amazon.marketplaceId,
          sellerSkus: sku,
          details: true,
        },
        timeout: 30000,
      });
      
      const items = response.data.inventorySummaries || [];
      if (items.length === 0) return 0;
      
      // totalQuantity es el stock disponible en Amazon
      return items[0].totalQuantity || 0;
    } catch (error: any) {
      console.error(`[AmazonService] Error obteniendo stock de ${sku}:`, error.response?.data || error.message);
      return 0;
    }
  }

  /**
   * Actualizar múltiples SKUs de una vez usando el Feed API
   * Más eficiente para sincronizaciones masivas
   */
  async updateInventoryBulk(skus: Array<{ sku: string; quantity: number }>): Promise<Record<string, boolean>> {
    const results: Record<string, boolean> = {};
    
    // Amazon SP-API tiene rate limits. Procesamos en lotes.
    for (const item of skus) {
      try {
        const success = await this.updateInventory(item.sku, item.quantity);
        results[item.sku] = success;
        
        // Rate limit: esperar entre requests
        await new Promise(r => setTimeout(r, 500));
      } catch (error) {
        results[item.sku] = false;
      }
    }
    
    return results;
  }
}
