import axios, { AxiosInstance } from 'axios';
import { BsaleProduct, BsaleStockResponse, BsaleVariant, BsaleVariantResponse, BsaleWebhookPayload } from '../types';
import { config } from '../config';

export class BsaleService {
  private client: AxiosInstance;
  
  constructor() {
    this.client = axios.create({
      baseURL: config.bsale.baseUrl,
      headers: {
        'access_token': config.bsale.token,
        'Content-Type': 'application/json',
      },
      timeout: 30000,
    });
  }

  /**
   * Obtener todas las variantes de productos con su stock
   */
  async getVariantsWithStock(limit: number = 50): Promise<BsaleVariant[]> {
    try {
      const response = await this.client.get<BsaleVariantResponse>(`/stocks.json`, {
        params: {
          limit,
          officeid: config.bsale.officeId,
          expand: 'variant,variant.product',
        },
      });
      
      return response.data.items || [];
    } catch (error) {
      console.error('[BsaleService] Error obteniendo variantes:', (error as Error).message);
      throw error;
    }
  }

  /**
   * Obtener stock de una variante específica por ID
   */
  async getStockByVariantId(variantId: number): Promise<number> {
    try {
      const response = await this.client.get<BsaleStockResponse>(`/stocks.json`, {
        params: {
          variantid: variantId,
          officeid: config.bsale.officeId,
        },
      });
      
      const items = response.data.items || [];
      if (items.length === 0) return 0;
      
      // quantityAvailable es el stock real disponible
      return items[0].quantityAvailable || 0;
    } catch (error) {
      console.error(`[BsaleService] Error obteniendo stock para variante ${variantId}:`, (error as Error).message);
      throw error;
    }
  }

  /**
   * Obtener stock de una variante por SKU
   */
  async getStockBySku(sku: string): Promise<number> {
    try {
      const response = await this.client.get<BsaleVariantResponse>(`/variants.json`, {
        params: {
          code: sku,
          limit: 1,
        },
      });
      
      const items = response.data.items || [];
      if (items.length === 0) {
        console.warn(`[BsaleService] SKU ${sku} no encontrado en BSale`);
        return 0;
      }
      
      const variantId = items[0].id;
      return this.getStockByVariantId(variantId);
    } catch (error) {
      console.error(`[BsaleService] Error obteniendo stock por SKU ${sku}:`, (error as Error).message);
      throw error;
    }
  }

  /**
   * Obtener una variante específica por su ID
   */
  async getVariantById(variantId: number): Promise<BsaleVariant | null> {
    try {
      const response = await this.client.get<{ variant: BsaleVariant }>(`/variants/${variantId}.json`);
      return response.data.variant || null;
    } catch (error) {
      console.error(`[BsaleService] Error obteniendo variante ${variantId}:`, (error as Error).message);
      return null;
    }
  }

  /**
   * Obtener producto completo con variantes
   */
  async getProductById(productId: number): Promise<BsaleProduct | null> {
    try {
      const response = await this.client.get<{ product: BsaleProduct }>(`/products/${productId}.json`, {
        params: { expand: 'variants,variants.stock' },
      });
      return response.data.product || null;
    } catch (error) {
      console.error(`[BsaleService] Error obteniendo producto ${productId}:`, (error as Error).message);
      return null;
    }
  }

  /**
   * Procesar webhook de BSale
   * Soporta: 'stock' (cambio de stock directo) y 'document' (venta/compra)
   */
  async processWebhook(payload: BsaleWebhookPayload): Promise<{ sku: string; stock: number } | null> {
    console.log(`[BsaleService] Webhook recibido: ${payload.topic} | Action: ${payload.action} | ResourceId: ${payload.resourceId}`);
    
    // Procesar webhook de stock (cambio directo en stock)
    if (payload.topic === 'stock') {
      return this.processStockWebhook(payload.resourceId);
    }
    
    // Procesar webhook de documento (venta/compra)
    if (payload.topic === 'document') {
      return this.processDocumentWebhook(payload.resourceId);
    }
    
    console.log(`[BsaleService] Webhook ignorado (topic=${payload.topic})`);
    return null;
  }

  /**
   * Procesar webhook de stock directo
   */
  private async processStockWebhook(variantId: number): Promise<{ sku: string; stock: number } | null> {
    const variant = await this.getVariantById(variantId);
    if (!variant) {
      console.warn(`[BsaleService] Variante ${variantId} no encontrada`);
      return null;
    }
    
    const stock = await this.getStockByVariantId(variant.id);
    return { sku: variant.code, stock };
  }

  /**
   * Procesar webhook de documento (venta/compra)
   * Obtiene los items del documento y sincroniza cada SKU afectado
   */
  private async processDocumentWebhook(documentId: number): Promise<{ sku: string; stock: number } | null> {
    try {
      // Obtener detalles del documento
      const response = await this.client.get(`/documents/${documentId}.json`, {
        params: { expand: 'details,details.variant' },
      });
      
      const document = response.data.document;
      if (!document || !document.details) {
        console.warn(`[BsaleService] Documento ${documentId} sin detalles`);
        return null;
      }
      
      // Tomar el primer item del documento (podría haber varios)
      const firstDetail = document.details[0];
      if (!firstDetail || !firstDetail.variantId) {
        console.warn(`[BsaleService] Primer item del documento ${documentId} sin variante`);
        return null;
      }
      
      const variant = await this.getVariantById(firstDetail.variantId);
      if (!variant) {
        console.warn(`[BsaleService] Variante ${firstDetail.variantId} no encontrada`);
        return null;
      }
      
      const stock = await this.getStockByVariantId(variant.id);
      console.log(`[BsaleService] Documento ${documentId} procesado. SKU: ${variant.code}, Stock: ${stock}`);
      
      return { sku: variant.code, stock };
    } catch (error) {
      console.error(`[BsaleService] Error procesando documento ${documentId}:`, (error as Error).message);
      return null;
    }
  }
}
