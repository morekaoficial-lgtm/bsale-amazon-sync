import { BsaleService } from './bsaleService';
import { AmazonService } from './amazonService';
import { SyncLog, SyncResult, BsaleWebhookPayload } from '../types';
import { config } from '../config';

/**
 * Servicio de sincronización entre BSale y Amazon
 * Orquesta el flujo: BSale (source of truth) → Amazon
 */
export class SyncService {
  private bsale: BsaleService;
  private amazon: AmazonService;
  private logs: SyncLog[] = [];
  private isRunning = false;

  constructor() {
    this.bsale = new BsaleService();
    this.amazon = new AmazonService();
  }

  /**
   * Sincronizar TODO el inventario de BSale a Amazon
   * Útil para sincronización inicial o forzada
   */
  async syncAllInventory(): Promise<SyncLog> {
    if (this.isRunning) {
      throw new Error('Ya hay una sincronización en progreso');
    }

    this.isRunning = true;
    const log: SyncLog = {
      id: `sync-${Date.now()}`,
      startedAt: new Date().toISOString(),
      totalProducts: 0,
      successCount: 0,
      errorCount: 0,
      results: [],
      triggeredBy: 'manual',
    };

    try {
      console.log('[SyncService] Iniciando sincronización completa...');

      // 1. Obtener todas las variantes con stock de BSale
      const variants = await this.bsale.getVariantsWithStock(200);
      log.totalProducts = variants.length;

      console.log(`[SyncService] ${variants.length} variantes encontradas en BSale`);

      // 2. Para cada variante, actualizar stock en Amazon
      for (const variant of variants) {
        const bsaleSku = variant.code;
        const stock = variant.stock?.[0]?.quantityAvailable || 0;

        // Aquí puedes agregar lógica de mapeo de SKU si difieren
        // const amazonSku = this.mapSku(bsaleSku);
        const amazonSku = bsaleSku;

        try {
          const success = await this.amazon.updateInventory(amazonSku, stock);

          const result: SyncResult = {
            bsaleSku,
            amazonSku,
            bsaleStock: stock,
            amazonStockUpdated: stock,
            success,
            timestamp: new Date().toISOString(),
          };

          if (!success) {
            result.error = 'Error actualizando en Amazon';
            log.errorCount++;
          } else {
            log.successCount++;
          }

          log.results.push(result);

          // Rate limiting entre requests
          await new Promise(r => setTimeout(r, 600));
        } catch (error) {
          log.errorCount++;
          log.results.push({
            bsaleSku,
            amazonSku,
            bsaleStock: stock,
            amazonStockUpdated: 0,
            success: false,
            error: (error as Error).message,
            timestamp: new Date().toISOString(),
          });
        }
      }

      log.finishedAt = new Date().toISOString();
      this.logs.push(log);

      console.log(`[SyncService] Sincronización completada: ${log.successCount} éxitos, ${log.errorCount} errores`);
      return log;
    } finally {
      this.isRunning = false;
    }
  }

  /**
   * Sincronizar un solo SKU (útil para webhooks)
   */
  async syncSingleSku(bsaleSku: string): Promise<SyncResult> {
    console.log(`[SyncService] Sincronizando SKU: ${bsaleSku}`);

    const stock = await this.bsale.getStockBySku(bsaleSku);
    const amazonSku = bsaleSku; // o mapear si difieren

    const success = await this.amazon.updateInventory(amazonSku, stock);

    const result: SyncResult = {
      bsaleSku,
      amazonSku,
      bsaleStock: stock,
      amazonStockUpdated: stock,
      success,
      timestamp: new Date().toISOString(),
      error: success ? undefined : 'Error actualizando en Amazon',
    };

    console.log(`[SyncService] SKU ${bsaleSku}: stock=${stock}, success=${success}`);
    return result;
  }

  /**
   * Procesar webhook de BSale
   */
  async handleBsaleWebhook(payload: BsaleWebhookPayload): Promise<SyncResult | null> {
    console.log('[SyncService] Procesando webhook de BSale...');

    const stockInfo = await this.bsale.processWebhook(payload);
    if (!stockInfo) {
      console.log('[SyncService] Webhook no requiere acción');
      return null;
    }

    return this.syncSingleSku(stockInfo.sku);
  }

  /**
   * Obtener logs de sincronización
   */
  getLogs(limit: number = 10): SyncLog[] {
    return this.logs.slice(-limit).reverse();
  }

  /**
   * Obtener estado de sincronización
   */
  getStatus() {
    return {
      isRunning: this.isRunning,
      lastSync: this.logs.length > 0 ? this.logs[this.logs.length - 1].startedAt : null,
      totalSyncs: this.logs.length,
    };
  }

  /**
   * Iniciar sincronización automática periódica
   */
  startAutoSync(): void {
    if (config.sync.intervalMinutes <= 0) {
      console.log('[SyncService] Sincronización automática desactivada');
      return;
    }

    const intervalMs = config.sync.intervalMinutes * 60 * 1000;
    console.log(`[SyncService] Sincronización automática cada ${config.sync.intervalMinutes} minutos`);

    setInterval(async () => {
      try {
        console.log('[SyncService] Ejecutando sincronización automática...');
        await this.syncAllInventory();
      } catch (error) {
        console.error('[SyncService] Error en sincronización automática:', (error as Error).message);
      }
    }, intervalMs);
  }
}
