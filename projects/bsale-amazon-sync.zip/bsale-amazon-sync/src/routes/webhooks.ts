import { Router, Request, Response } from 'express';
import { SyncService } from '../services/syncService';
import { BsaleWebhookPayload } from '../types';

const router = Router();
const syncService = new SyncService();

// ============================================
// Health Check
// ============================================
router.get('/health', (_req: Request, res: Response) => {
  res.json({
    status: 'ok',
    service: 'bsale-amazon-sync',
    timestamp: new Date().toISOString(),
    syncStatus: syncService.getStatus(),
  });
});

// ============================================
// Webhook de BSale
// ============================================
router.post('/bsale', async (req: Request, res: Response) => {
  try {
    const payload = req.body as BsaleWebhookPayload;
    
    console.log('[Webhook] BSale webhook recibido:', JSON.stringify(payload));
    
    // Responder inmediatamente a BSale (webhooks deben ser rápidos)
    res.status(200).json({ received: true, processing: true });
    
    // Procesar en background
    const result = await syncService.handleBsaleWebhook(payload);
    
    if (result) {
      console.log('[Webhook] Sincronización completada:', result);
    }
  } catch (error) {
    console.error('[Webhook] Error procesando webhook:', (error as Error).message);
    // Ya respondimos 200, solo logueamos el error
  }
});

// ============================================
// Sincronización manual
// ============================================

// Sincronizar TODO el inventario
router.post('/sync/all', async (_req: Request, res: Response) => {
  try {
    // Responder inmediatamente y procesar en background
    res.status(202).json({ 
      message: 'Sincronización iniciada',
      status: 'processing',
    });
    
    // Procesar en background
    const log = await syncService.syncAllInventory();
    console.log('[Sync] Sincronización completa finalizada:', log);
  } catch (error) {
    console.error('[Sync] Error:', (error as Error).message);
    // Ya respondimos 202
  }
});

// Sincronizar un SKU específico
router.post('/sync/sku/:sku', async (req: Request, res: Response) => {
  try {
    const sku = req.params.sku;
    const result = await syncService.syncSingleSku(sku);
    res.json(result);
  } catch (error) {
    res.status(500).json({
      error: (error as Error).message,
      sku: req.params.sku,
    });
  }
});

// ============================================
// Logs y estado
// ============================================

// Obtener logs de sincronización
router.get('/logs', (req: Request, res: Response) => {
  const limit = parseInt(req.query.limit as string || '10', 10);
  res.json(syncService.getLogs(limit));
});

// Obtener estado de sincronización
router.get('/status', (_req: Request, res: Response) => {
  res.json(syncService.getStatus());
});

export default router;
