# BSale ↔ Amazon Sync

Sincronización automática de inventario entre **BSale** (tu ERP) y **Amazon Seller Central** usando webhooks y la Selling Partner API (SP-API).

## 🏗️ Arquitectura

```
┌─────────────┐     Webhook (stock)     ┌─────────────────┐
│   BSale     │ ──────────────────────► │  Este Servidor  │
│   (ERP)     │                         │  (Node.js)      │
└─────────────┘                         └────────┬────────┘
                                                 │
                    Sincronización periódica     │
                    o manual                     │
                                                 ▼
                                        ┌─────────────────┐
                                        │  Amazon SP-API  │
                                        │  (Seller Central)│
                                        └─────────────────┘
```

## 📋 Requisitos Previos

- Node.js 20+
- Cuenta en BSale con acceso a API
- Cuenta de vendedor en Amazon (Seller Central)
- Servidor VPS (recomendado DigitalOcean)

---

## 🔑 Paso 1: Obtener Credenciales de BSale

### 1.1 Registrarte / Acceder a BSale API

1. Ve a [https://api.bsale.io/](https://api.bsale.io/)
2. Inicia sesión con tu cuenta de BSale
3. Ve a **"Mi Cuenta"** o **"Developer"**

### 1.2 Generar Access Token

1. En el panel de BSale API, busca la opción **"Generar Token"**
2. Selecciona los permisos necesarios:
   - ✅ `stock` — Lectura de stock
   - ✅ `variants` — Lectura de variantes/productos
   - ✅ `products` — Lectura de productos
3. Copia el token generado (empieza con algo como `Bearer ...` o un token largo)

### 1.3 Obtener el Office ID

1. En BSale, ve a **Configuración → Sucursales/Oficinas**
2. Anota el ID de la oficina principal (usualmente `1` si solo tienes una)
3. O usa la API: `GET https://api.bsale.io/v1/offices.json` con tu token

---

## 🔑 Paso 2: Obtener Credenciales de Amazon SP-API

Este es el paso más complejo. Amazon SP-API requiere varias credenciales.

### 2.1 Crear una cuenta de desarrollador en Amazon

1. Ve a [Amazon Seller Central](https://sellercentral.amazon.com) (o `.com.mx` para México)
2. Inicia sesión con tu cuenta de vendedor
3. Ve a: **Settings → User Permissions**
4. En la sección **"Amazon MWS Developer Permissions"** o **"SP-API"**, haz clic en **"Authorize a Developer"**
5. Si aún no eres desarrollador, primero debes registrarte como tal:
   - Ve al [Developer Central](https://developer.amazon.com/)
   - Registra tu aplicación
   - Completa el formulario de solicitud (toma 1-2 días la aprobación)

### 2.2 Registrar tu aplicación en Seller Central

1. En Seller Central, ve a **Apps & Services → Develop Apps**
2. Clic en **"Add new app"**
3. Completa:
   - **App name**: `BSale Sync App`
   - **API Type**: `SP-API`
   - Selecciona los roles necesarios:
     - ✅ `Inventory and Order Tracking`
     - ✅ `Product Listing`
   - Guarda la aplicación

### 2.3 Obtener credenciales LWA (Login with Amazon)

Después de registrar tu app, Amazon te dará:

- **LWA Client ID** (empieza con `amzn1.application-oa2-client.`)
- **LWA Client Secret** (string largo)

Guárdalos de forma segura.

### 2.4 Obtener Refresh Token

1. En la misma página de tu app en Seller Central
2. Busca **"Authorize"** o **"Generate tokens"**
3. Selecciona tu marketplace (ej: Amazon.com.mx)
4. Autoriza la aplicación
5. Copia el **Refresh Token** (es muy largo, empieza con `Atzr|`)

> ⚠️ El refresh token no expira (a menos que revoques el acceso), pero el **access token** sí expira cada hora.

### 2.5 Obtener credenciales AWS IAM

Amazon SP-API requiere que firmes las peticiones con AWS Signature v4.

#### Opción A: IAM User (más simple)

1. Ve a [AWS Console](https://console.aws.amazon.com/)
2. Ve a **IAM → Users → Add user**
3. Nombre: `sp-api-user`
4. Acceso: **Programmatic access** (solo Access Key, no console)
5. Permisos: **Attach existing policies directly**
   - Busca y selecciona: `AmazonSNSFullAccess` (para notificaciones, opcional)
   - O crea una política personalizada vacía si solo necesitas firmar requests
6. Crea el usuario y **copia**:
   - **Access Key ID** (empieza con `AKIA...`)
   - **Secret Access Key**

#### Opción B: IAM Role (más seguro, recomendado para producción)

1. Ve a **IAM → Roles → Create role**
2. Tipo: **AWS account** → tu propia cuenta
3. Política: Crea una política vacía o usa mínimos permisos
4. Crea el rol y copia el **Role ARN** (empieza con `arn:aws:iam::...`)

### 2.6 Identificar tu Marketplace ID

| País | Marketplace ID |
|------|---------------|
| México | `A1AM78C64UM0Y8` |
| Estados Unidos | `ATVPDKIKX0DER` |
| Brasil | `A2Q3Y263D00KWC` |
| Canadá | `A2EUQ1WTGCTBG2` |
| Reino Unido | `A1F83G8C2ARO7P` |

---

## 🚀 Paso 3: Configurar y Desplegar

### 3.1 Clonar y configurar el proyecto

```bash
# En tu servidor (DigitalOcean)
git clone <tu-repo> bsale-amazon-sync
cd bsale-amazon-sync
npm install

# Copiar archivo de configuración
cp .env.example .env

# Editar .env con tus credenciales
nano .env
```

### 3.2 Configurar variables de entorno

Edita `.env` con todos los valores obtenidos:

```env
# BSale
BSALE_API_TOKEN=tu_token_aqui
BSALE_BASE_URL=https://api.bsale.io/v1
BSALE_OFFICE_ID=1

# Amazon
AMAZON_LWA_CLIENT_ID=amzn1.application-oa2-client.xxx
AMAZON_LWA_CLIENT_SECRET=xxx
AMAZON_REFRESH_TOKEN=Atzr|xxx
AMAZON_AWS_ACCESS_KEY=AKIAxxx
AMAZON_AWS_SECRET_KEY=xxx
AMAZON_MARKETPLACE_ID=A1AM78C64UM0Y8

# Sync
SYNC_INTERVAL_MINUTES=30
```

### 3.3 Compilar y ejecutar

```bash
# Compilar TypeScript
npm run build

# Iniciar en modo producción
npm start

# O con PM2 para producción
pm2 start dist/app.js --name bsale-amazon-sync
pm2 save
pm2 startup
```

### 3.4 Configurar webhook en BSale

1. Ve a tu panel de BSale → **Integraciones → Webhooks**
2. Crea un nuevo webhook:
   - **URL**: `https://tu-dominio.com/webhook/bsale`
   - **Topic**: `stock`
   - **Método**: `POST`
3. Guarda y verifica que el webhook esté activo

---

## 📡 Endpoints del Servidor

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/` | Info del servicio |
| GET | `/webhook/health` | Health check |
| POST | `/webhook/bsale` | Recibe webhooks de BSale |
| POST | `/webhook/sync/all` | Sincronizar todo el inventario |
| POST | `/webhook/sync/sku/:sku` | Sincronizar un SKU específico |
| GET | `/webhook/logs` | Ver logs de sincronización |
| GET | `/webhook/status` | Estado de sincronización |

---

## 🛡️ Seguridad

- Usa HTTPS en producción (Let's Encrypt es gratis)
- Guarda el `.env` de forma segura (nunca lo subas a Git)
- Considera usar un firewall (UFW) en DigitalOcean
- El token de BSale y las credenciales de Amazon son sensibles

---

## 🐛 Troubleshooting

### Error 401 en Amazon
- Verifica que el refresh token no haya expirado
- Revisa que el LWA Client ID y Secret sean correctos

### Error 403 en Amazon
- Verifica que tu app tenga los permisos necesarios en Seller Central
- Asegúrate de que las credenciales AWS tengan los permisos correctos

### No se reciben webhooks de BSale
- Verifica que la URL del webhook sea accesible públicamente
- Usa `curl` para probar: `curl -X POST https://tu-dominio/webhook/bsale`
- Revisa los logs del servidor

### Stock no se actualiza en Amazon
- Verifica que el SKU en BSale coincida con el de Amazon
- Revisa los rate limits de SP-API (implementamos delays para esto)

---

## 📚 Documentación Adicional

- [BSale API Docs](https://github.com/bsaleio/documentacion)
- [Amazon SP-API Docs](https://developer-docs.amazon.com/sp-api/)
- [Amazon SP-API JavaScript SDK](https://github.com/amzn/selling-partner-api-sdk)

---

## 📝 Licencia

Proyecto privado.
