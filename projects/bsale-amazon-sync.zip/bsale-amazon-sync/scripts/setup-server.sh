#!/bin/bash
# ============================================
# Setup inicial de servidor DigitalOcean
# ============================================

set -e

DOMAIN="${DOMAIN:-tu-dominio.com}"
PROJECT_NAME="bsale-amazon-sync"
PROJECT_DIR="/var/www/${PROJECT_NAME}"

echo "🖥️  Setup de servidor DigitalOcean para BSale ↔ Amazon Sync"
echo "Dominio: ${DOMAIN}"
echo ""

# 1. Actualizar sistema
echo "📦 Actualizando sistema..."
apt-get update && apt-get upgrade -y

# 2. Instalar Node.js 20
echo "⬇️  Instalando Node.js 20..."
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt-get install -y nodejs

# 3. Instalar PM2
echo "⬇️  Instalando PM2..."
npm install -g pm2

# 4. Instalar Nginx
echo "⬇️  Instalando Nginx..."
apt-get install -y nginx

# 5. Instalar Certbot (Let's Encrypt)
echo "⬇️  Instalando Certbot..."
apt-get install -y certbot python3-certbot-nginx

# 6. Crear directorio del proyecto
echo "📁 Creando directorio del proyecto..."
mkdir -p ${PROJECT_DIR}
chown -R $USER:$USER ${PROJECT_DIR}

# 7. Configurar firewall
echo "🛡️  Configurando firewall..."
ufw allow 'Nginx Full'
ufw allow OpenSSH
ufw --force enable

# 8. Crear configuración Nginx
echo "🌐 Configurando Nginx..."
cat > /etc/nginx/sites-available/${PROJECT_NAME} << 'NGINX'
server {
    listen 80;
    server_name _;  # Cambiar por tu dominio

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
NGINX

ln -sf /etc/nginx/sites-available/${PROJECT_NAME} /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default

nginx -t && systemctl restart nginx

echo ""
echo "✅ Setup completado!"
echo ""
echo "📋 Próximos pasos:"
echo "1. Configura tu dominio apuntando a esta IP"
echo "2. Sube el proyecto a ${PROJECT_DIR}"
echo "3. Configura el archivo .env"
echo "4. Ejecuta: npm install && npm run build"
echo "5. Inicia con: pm2 start dist/app.js --name ${PROJECT_NAME}"
echo "6. (Opcional) Configura SSL: certbot --nginx -d ${DOMAIN}"
echo ""
