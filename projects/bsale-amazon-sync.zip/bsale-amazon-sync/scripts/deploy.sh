#!/bin/bash
# ============================================
# Script de deploy a DigitalOcean
# ============================================

set -e

SERVER_IP="${SERVER_IP:-tu_ip_aqui}"
SERVER_USER="${SERVER_USER:-root}"
PROJECT_NAME="bsale-amazon-sync"
REMOTE_DIR="/var/www/${PROJECT_NAME}"

echo "🚀 Deploy de BSale ↔ Amazon Sync a DigitalOcean"
echo "Servidor: ${SERVER_USER}@${SERVER_IP}"
echo ""

# 1. Build local
echo "📦 Compilando proyecto..."
npm run build

# 2. Crear directorio remoto y subir archivos
echo "📤 Subiendo archivos al servidor..."
ssh ${SERVER_USER}@${SERVER_IP} "mkdir -p ${REMOTE_DIR}"

# Subir archivos necesarios (excluyendo node_modules y .env)
rsync -avz --exclude='node_modules' --exclude='.env' --exclude='.git' \
  ./ ${SERVER_USER}@${SERVER_IP}:${REMOTE_DIR}/

# 3. Instalar dependencias y configurar en servidor
echo "🔧 Instalando dependencias en servidor..."
ssh ${SERVER_USER}@${SERVER_IP} << EOF
  cd ${REMOTE_DIR}
  
  # Instalar Node.js 20 si no está
  if ! command -v node &> /dev/null || [ "\$(node -v | cut -d'v' -f2 | cut -d'.' -f1)" != "20" ]; then
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y nodejs
  fi
  
  # Instalar PM2 si no está
  if ! command -v pm2 &> /dev/null; then
    npm install -g pm2
  fi
  
  # Instalar dependencias
  npm install
  
  # Compilar
  npm run build
  
  # Crear .env si no existe (el usuario debe editarlo después)
  if [ ! -f .env ]; then
    cp .env.example .env
    echo "⚠️  IMPORTANTE: Edita ${REMOTE_DIR}/.env con tus credenciales"
  fi
  
  # Reiniciar o iniciar servicio
  pm2 restart ${PROJECT_NAME} || pm2 start dist/app.js --name ${PROJECT_NAME}
  pm2 save
  pm2 startup
  
  echo "✅ Deploy completado!"
EOF

echo ""
echo "📋 Próximos pasos:"
echo "1. SSH al servidor: ssh ${SERVER_USER}@${SERVER_IP}"
echo "2. Edita las credenciales: nano ${REMOTE_DIR}/.env"
echo "3. Reinicia el servicio: pm2 restart ${PROJECT_NAME}"
echo "4. Verifica que funcione: curl http://${SERVER_IP}:3000/"
echo ""
echo "🎉 Listo!"
